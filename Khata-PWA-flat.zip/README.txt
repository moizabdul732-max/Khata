KHATA APP - flat version (koi folder nahi, phone se upload ho jata hai)
Saari 8 files GitHub repository me upload karein (purani files ko same naam se replace kar dein):
index.html, sw.js, manifest.webmanifest, icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png, README.txt
